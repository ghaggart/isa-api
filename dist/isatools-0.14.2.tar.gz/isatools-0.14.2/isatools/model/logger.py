from logging import getLogger, DEBUG

log = getLogger('isatools')
log.setLevel(DEBUG)
