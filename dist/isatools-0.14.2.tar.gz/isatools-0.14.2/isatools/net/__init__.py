"""This package provides modules for using network services"""
